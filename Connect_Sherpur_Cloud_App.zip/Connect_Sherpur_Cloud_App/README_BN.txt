Connect Sherpur GA Auto Report — Cloud App Starter

এই ZIP-এ আছে:
- app.py: Streamlit অ্যাপ কোড
- requirements.txt: প্রয়োজনীয় লাইব্রেরি

গুরুত্বপূর্ণ: template.xlsx এই ZIP-এ ইচ্ছাকৃতভাবে রাখা হয়নি, যাতে 48 MB-এর ব্যক্তিগত/ব্যবসায়িক Excel ফাইল GitHub-এ আপলোড করতে না হয়।

মোবাইল দিয়ে চালুর সংক্ষিপ্ত ধাপ:
1. ZIP Extract করুন।
2. GitHub-এ একটি নতুন repository তৈরি করুন (Private রাখাই ভালো)।
3. app.py ও requirements.txt আপলোড করুন। README_BN.txt ঐচ্ছিক। template.xlsx আপলোড করবেন না।
4. Streamlit Community Cloud-এ GitHub দিয়ে লগইন করে repository-এর app.py deploy করুন।
5. অ্যাপ চালু হলে প্রথম আপলোড বক্সে আপনার মূল Connect Sherpur GA Excel ফাইল (template.xlsx) নির্বাচন করুন। দ্বিতীয় বক্সে নতুন Activation Report নির্বাচন করুন।
6. GENERATE REPORT চাপুন এবং তৈরি XLSX ডাউনলোড করুন।

সীমাবদ্ধতা ও সতর্কতা:
- এই কোডটি প্রাথমিক সংস্করণ; সব ধরনের PDF/Excel ফাইলের জন্য নিশ্চিত নয়। PDF-এর স্ক্যান করা ছবি OCR ছাড়া পড়া যাবে না।
- রিপোর্ট ফাইলের কলামগুলো প্রত্যাশিত ActivationReport format-এর সঙ্গে মিলতে হবে।
- তৈরি রিপোর্ট প্রথমবার মূল Excel-এর সঙ্গে মিলিয়ে যাচাই করুন।
- Template ফাইলটি প্রতিবার অ্যাপে আপলোড করতে হবে। এতে GitHub-এ বড় workbook রাখার দরকার নেই, তবে আপলোডে সময় লাগতে পারে।
